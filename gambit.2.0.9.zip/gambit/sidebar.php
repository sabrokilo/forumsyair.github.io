<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Gambit
 */

// Display Main Sidebar.
get_sidebar( 'main' );

// Display Small Sidebar.
get_sidebar( 'small' );
